=== Newsroom Creator ===
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later

Receives article drafts from the Newsroom Creator app and creates WordPress draft posts for admin review.

== Installation ==

1. Upload the `newsroom-creator` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **Settings → Newsroom Creator** to find your Site URL and API key.
4. In the Newsroom Creator app, go to **System → WordPress Integration** and paste those values.
5. Click **Push to WordPress** on any generated article to create a draft post.

== Changelog ==

= 1.0.0 =
* Initial release.
