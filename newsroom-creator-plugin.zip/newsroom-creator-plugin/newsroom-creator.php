<?php
/**
 * Plugin Name:       Newsroom Creator
 * Description:       Receives article drafts from the Newsroom Creator app via a secure REST API endpoint.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            VOGUK
 * License:           GPL v2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct file access
}

define( 'NEWSROOM_CREATOR_VERSION', '1.1.0' );
define( 'NEWSROOM_CREATOR_OPTION_KEY', 'newsroom_creator_api_key' );

// ---------------------------------------------------------------------------
// 1. Plugin activation – generate an API key on first activation
// ---------------------------------------------------------------------------
register_activation_hook( __FILE__, 'newsroom_creator_activate' );

function newsroom_creator_activate() {
    if ( ! get_option( NEWSROOM_CREATOR_OPTION_KEY ) ) {
        // Generate a cryptographically secure random key
        $key = bin2hex( random_bytes( 32 ) ); // 64 hex characters
        update_option( NEWSROOM_CREATOR_OPTION_KEY, $key );
    }
}

// ---------------------------------------------------------------------------
// 2. Register the REST API endpoints
// ---------------------------------------------------------------------------
add_action( 'rest_api_init', 'newsroom_creator_register_routes' );

function newsroom_creator_register_routes() {
    // Create / update draft endpoint
    register_rest_route(
        'newsroom-creator/v1',
        '/create-draft',
        array(
            'methods'             => 'POST',
            'callback'            => 'newsroom_creator_handle_request',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );

    // Connection test endpoint
    register_rest_route(
        'newsroom-creator/v1',
        '/test',
        array(
            'methods'             => 'GET',
            'callback'            => 'newsroom_creator_handle_test',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );
}

/**
 * Validate the API key sent in the X-Newsroom-API-Key header.
 */
function newsroom_creator_check_api_key( WP_REST_Request $request ) {
    $stored_key  = get_option( NEWSROOM_CREATOR_OPTION_KEY, '' );
    $header_key  = $request->get_header( 'X-Newsroom-API-Key' );

    if ( empty( $stored_key ) || empty( $header_key ) ) {
        return new WP_Error(
            'rest_forbidden',
            'API key is missing.',
            array( 'status' => 401 )
        );
    }

    // Constant-time comparison to prevent timing attacks
    if ( ! hash_equals( $stored_key, $header_key ) ) {
        return new WP_Error(
            'rest_forbidden',
            'Invalid API key.',
            array( 'status' => 403 )
        );
    }

    return true;
}

/**
 * Connection test – simply confirms the plugin is active and the key is valid.
 */
function newsroom_creator_handle_test( WP_REST_Request $request ) {
    return new WP_REST_Response(
        array(
            'success' => true,
            'message' => 'Newsroom Creator plugin is active and your API key is valid.',
        ),
        200
    );
}

/**
 * Create or update a draft post from the incoming data.
 */
function newsroom_creator_handle_request( WP_REST_Request $request ) {
    $params  = $request->get_json_params();
    $title   = isset( $params['title'] )   ? sanitize_text_field( $params['title'] )   : '';
    $content = isset( $params['content'] ) ? wp_kses_post( $params['content'] )         : '';

    if ( empty( $title ) || empty( $content ) ) {
        return new WP_Error(
            'missing_fields',
            'Both title and content are required.',
            array( 'status' => 400 )
        );
    }

    // If a post_id is supplied, update the existing draft instead of creating a new one
    $existing_post_id = isset( $params['post_id'] ) ? intval( $params['post_id'] ) : 0;

    if ( $existing_post_id > 0 && get_post( $existing_post_id ) ) {
        $post_id = wp_update_post(
            array(
                'ID'           => $existing_post_id,
                'post_title'   => $title,
                'post_content' => $content,
                'post_status'  => 'draft',
            ),
            true
        );
        $http_status = 200;
    } else {
        $post_id = wp_insert_post(
            array(
                'post_title'   => $title,
                'post_content' => $content,
                'post_status'  => 'draft',
                'post_type'    => 'post',
            ),
            true // Return WP_Error on failure
        );
        $http_status = 201;
    }

    if ( is_wp_error( $post_id ) ) {
        return new WP_REST_Response(
            array(
                'success' => false,
                'message' => $post_id->get_error_message(),
            ),
            500
        );
    }

    return new WP_REST_Response(
        array(
            'success'  => true,
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link( $post_id, 'raw' ),
        ),
        $http_status
    );
}

// ---------------------------------------------------------------------------
// 3. Admin settings page
// ---------------------------------------------------------------------------
add_action( 'admin_menu', 'newsroom_creator_admin_menu' );

function newsroom_creator_admin_menu() {
    add_options_page(
        'Newsroom Creator',
        'Newsroom Creator',
        'manage_options',
        'newsroom-creator',
        'newsroom_creator_settings_page'
    );
}

function newsroom_creator_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $api_key        = get_option( NEWSROOM_CREATOR_OPTION_KEY, '' );
    $regenerated    = false;
    $regenerate_url = wp_nonce_url(
        add_query_arg( 'newsroom_regen', '1', admin_url( 'options-general.php?page=newsroom-creator' ) ),
        'newsroom_creator_regen'
    );

    // Handle key regeneration
    if (
        isset( $_GET['newsroom_regen'] ) &&
        isset( $_GET['_wpnonce'] ) &&
        wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'newsroom_creator_regen' )
    ) {
        $api_key = bin2hex( random_bytes( 32 ) );
        update_option( NEWSROOM_CREATOR_OPTION_KEY, $api_key );
        $regenerated = true;
    }
    ?>
    <div class="wrap">
        <h1>Newsroom Creator — Settings</h1>

        <?php if ( $regenerated ) : ?>
            <div class="notice notice-success is-dismissible"><p>API key regenerated successfully.</p></div>
        <?php endif; ?>

        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:24px;max-width:640px;margin-top:20px;">

            <h2 style="margin-top:0;">REST API Endpoint</h2>
            <p>Configure the <strong>Newsroom Creator</strong> app's System page with these details:</p>

            <table class="form-table" style="margin-top:0;">
                <tr>
                    <th scope="row" style="padding-left:0;">WordPress Site URL</th>
                    <td>
                        <code style="background:#f0f0f1;padding:4px 8px;border-radius:3px;font-size:13px;">
                            <?php echo esc_html( home_url() ); ?>
                        </code>
                        <p class="description">Copy this into the <em>WordPress Site URL</em> field in the app.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row" style="padding-left:0;">API Key</th>
                    <td>
                        <input
                            type="text"
                            id="newsroom-api-key"
                            value="<?php echo esc_attr( $api_key ); ?>"
                            readonly
                            style="width:100%;font-family:monospace;font-size:13px;"
                        >
                        <p class="description">Copy this into the <em>API Key</em> field in the app.</p>
                        <p style="margin-top:12px;">
                            <button
                                type="button"
                                onclick="
                                    var el = document.getElementById('newsroom-api-key');
                                    el.select();
                                    document.execCommand('copy');
                                    this.textContent = 'Copied!';
                                    var btn = this;
                                    setTimeout(function(){ btn.textContent = 'Copy to Clipboard'; }, 2000);
                                "
                                class="button"
                            >Copy to Clipboard</button>
                            &nbsp;
                            <a
                                href="<?php echo esc_url( $regenerate_url ); ?>"
                                class="button"
                                onclick="return confirm('Regenerate API key? The old key will stop working immediately.');"
                            >Regenerate Key</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row" style="padding-left:0;">Endpoint URL</th>
                    <td>
                        <code style="background:#f0f0f1;padding:4px 8px;border-radius:3px;font-size:13px;">
                            <?php echo esc_html( home_url( '/wp-json/newsroom-creator/v1/create-draft' ) ); ?>
                        </code>
                        <p class="description">For reference only — the app constructs this automatically from the site URL above.</p>
                    </td>
                </tr>
            </table>

            <hr>

            <h2>How it works</h2>
            <ol>
                <li>Install &amp; activate this plugin on your WordPress site.</li>
                <li>Go to <strong>Settings → Newsroom Creator</strong> and copy the <em>Site URL</em> and <em>API Key</em>.</li>
                <li>In the Newsroom Creator app, go to <strong>System → WordPress Integration</strong> and paste those values, then click <em>Save WordPress Settings</em>.</li>
                <li>When editing an article in the app, click <strong>Push to WordPress</strong>. The article will appear as a <strong>Draft</strong> post in your WordPress admin for review before publishing.</li>
            </ol>
        </div>
    </div>
    <?php
}
