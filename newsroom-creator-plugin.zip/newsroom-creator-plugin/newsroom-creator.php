<?php
/**
 * Plugin Name:       Newsroom Creator
 * Description:       Receives article drafts from the Newsroom Creator app via a secure REST API endpoint.
 * Version:           1.6.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            VBI
 * License:           Copyright (c) 2026 VBI. See the LICENSE file in plugin folder. Modification is strictly prohibited without a Commercial Modification License.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct file access
}

define( 'NEWSROOM_CREATOR_VERSION', '1.4.0' );
define( 'NEWSROOM_CREATOR_OPTION_KEY', 'newsroom_creator_api_key' );

register_activation_hook( __FILE__, 'newsroom_creator_activate' );

function newsroom_creator_activate() {
    if ( ! get_option( NEWSROOM_CREATOR_OPTION_KEY ) ) {
        $key = bin2hex( random_bytes( 32 ) ); 
        update_option( NEWSROOM_CREATOR_OPTION_KEY, $key );
    }
}

add_action( 'rest_api_init', 'newsroom_creator_register_routes' );

function newsroom_creator_register_routes() {
    register_rest_route(
        'newsroom-creator/v1',
        '/create-draft',
        array(
            'methods'             => 'POST',
            'callback'            => 'newsroom_creator_handle_request',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );

    register_rest_route(
        'newsroom-creator/v1',
        '/test',
        array(
            'methods'             => 'GET',
            'callback'            => 'newsroom_creator_handle_test',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );

    register_rest_route(
        'newsroom-creator/v1',
        '/meta',
        array(
            'methods'             => 'GET',
            'callback'            => 'newsroom_creator_get_meta',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );

    register_rest_route(
        'newsroom-creator/v1',
        '/posts',
        array(
            'methods'             => 'GET',
            'callback'            => 'newsroom_creator_get_posts',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );

    register_rest_route(
        'newsroom-creator/v1',
        '/trash-post',
        array(
            'methods'             => 'POST',
            'callback'            => 'newsroom_creator_trash_post',
            'permission_callback' => 'newsroom_creator_check_api_key',
        )
    );
}

function newsroom_creator_check_api_key( WP_REST_Request $request ) {
    $stored_key  = get_option( NEWSROOM_CREATOR_OPTION_KEY, '' );
    $header_key  = $request->get_header( 'X-Newsroom-API-Key' );

    if ( empty( $stored_key ) || empty( $header_key ) ) {
        return new WP_Error( 'rest_forbidden', 'API key is missing.', array( 'status' => 401 ) );
    }
    if ( ! hash_equals( $stored_key, $header_key ) ) {
        return new WP_Error( 'rest_forbidden', 'Invalid API key.', array( 'status' => 403 ) );
    }
    return true;
}

function newsroom_creator_handle_test( WP_REST_Request $request ) {
    return new WP_REST_Response( array( 'success' => true, 'message' => 'Active.' ), 200 );
}

function newsroom_creator_get_meta( WP_REST_Request $request ) {
    $categories = get_categories( array( 'hide_empty' => false ) );
    $tags = get_tags( array( 'hide_empty' => false ) );
    $users = get_users( array( 'who' => 'authors' ) );

    $cat_data = array();
    foreach ( $categories as $cat ) {
        $cat_data[] = array( 'id' => $cat->term_id, 'name' => $cat->name );
    }

    $tag_data = array();
    foreach ( $tags as $tag ) {
        $tag_data[] = array( 'id' => $tag->term_id, 'name' => $tag->name );
    }

    $user_data = array();
    foreach ( $users as $user ) {
        $user_data[] = array( 'id' => $user->ID, 'name' => $user->display_name );
    }

    return new WP_REST_Response( array(
        'success'    => true,
        'categories' => $cat_data,
        'tags'       => $tag_data,
        'authors'    => $user_data
    ), 200 );
}

function newsroom_creator_handle_request( WP_REST_Request $request ) {
    $params  = $request->get_json_params();
    $title   = isset( $params['title'] )   ? sanitize_text_field( $params['title'] )   : '';
    $content = isset( $params['content'] ) ? wp_kses_post( $params['content'] )         : '';

    if ( empty( $title ) || empty( $content ) ) {
        return new WP_Error( 'missing_fields', 'Both title and content are required.', array( 'status' => 400 ) );
    }

    $post_data = array(
        'post_title'   => $title,
        'post_content' => $content,
        'post_status'  => isset( $params['status'] ) ? sanitize_text_field( $params['status'] ) : 'draft',
    );

    if ( ! empty( $params['author'] ) ) {
        $post_data['post_author'] = intval( $params['author'] );
    }
    
    if ( ! empty( $params['date'] ) ) {
        $post_data['post_date'] = sanitize_text_field( $params['date'] );
    }
    
    if ( ! empty( $params['categories'] ) && is_array( $params['categories'] ) ) {
        $post_data['post_category'] = array_map( 'intval', $params['categories'] );
    }

    $existing_post_id = isset( $params['post_id'] ) ? intval( $params['post_id'] ) : 0;

    if ( $existing_post_id > 0 && get_post( $existing_post_id ) ) {
        $post_data['ID'] = $existing_post_id;
        $post_id = wp_update_post( $post_data, true );
        $http_status = 200;
    } else {
        $post_data['post_type'] = 'post';

        // CLEAN SLUG ATTEMPT: Try the title first
        $base_slug = sanitize_title( $title );
        $final_slug = $base_slug;

        // SAFEGUARD: Check if the slug exists using a REST-safe query (post_exists() is admin-only).
        $slug_taken = (bool) get_page_by_path( $base_slug, OBJECT, 'post' );
        if ( ! $slug_taken ) {
            $existing = get_posts( array(
                'post_type'      => 'post',
                'post_status'    => 'any',
                'title'          => $title,
                'posts_per_page' => 1,
                'fields'         => 'ids',
            ) );
            $slug_taken = ! empty( $existing );
        }
        if ( $slug_taken ) {
            $unique_hash = substr( md5( uniqid( wp_rand(), true ) ), 0, 6 );
            $final_slug = $base_slug . '-' . $unique_hash;
        }

        $post_data['post_name'] = $final_slug;
        $post_id = wp_insert_post( $post_data, true );
        $http_status = 201;
    }

    if ( is_wp_error( $post_id ) ) {
        return new WP_REST_Response( array( 'success' => false, 'message' => $post_id->get_error_message() ), 500 );
    }

    if ( ! empty( $params['tags'] ) ) {
        $tags_list = is_array($params['tags']) ? $params['tags'] : explode(',', $params['tags']);
        $clean_tags = array_map('sanitize_text_field', $tags_list);
        wp_set_post_tags( $post_id, $clean_tags, false );
    }

    // Handle Featured Image — wrapped in try/catch so any image-processing error never kills the request
    if ( ! empty( $params['featured_image_base64'] ) ) {
        try {
            $base64_img  = $params['featured_image_base64'];
            $image_parts = explode( ';base64,', $base64_img );

            if ( count( $image_parts ) === 2 ) {
                $image_type_aux = explode( 'image/', $image_parts[0] );
                $image_type     = isset( $image_type_aux[1] ) ? preg_replace( '/[^a-zA-Z0-9]/', '', $image_type_aux[1] ) : 'jpeg';
                $image_data     = base64_decode( $image_parts[1], true );

                if ( $image_data !== false && strlen( $image_data ) > 0 ) {
                    $unique_img_hash = substr( md5( uniqid( wp_rand(), true ) ), 0, 10 );
                    $file_name       = sanitize_title( $title ) . '-' . $unique_img_hash . '.' . $image_type;
                    $upload_dir      = wp_upload_dir();
                    $file_path       = $upload_dir['path'] . '/' . $file_name;

                    if ( file_put_contents( $file_path, $image_data ) !== false ) {
                        require_once ABSPATH . 'wp-admin/includes/image.php';
                        require_once ABSPATH . 'wp-admin/includes/media.php';
                        require_once ABSPATH . 'wp-admin/includes/file.php';

                        $img_title   = ! empty( $params['img_title'] )   ? sanitize_text_field( $params['img_title'] )       : sanitize_text_field( $title );
                        $img_caption = ! empty( $params['img_caption'] ) ? sanitize_textarea_field( $params['img_caption'] ) : '';
                        $img_alt     = ! empty( $params['img_alt'] )     ? sanitize_text_field( $params['img_alt'] )         : '';

                        $attachment = array(
                            'guid'           => $upload_dir['url'] . '/' . $file_name,
                            'post_mime_type' => 'image/' . $image_type,
                            'post_title'     => $img_title,
                            'post_excerpt'   => $img_caption,
                            'post_content'   => '',
                            'post_status'    => 'inherit',
                        );

                        $attach_id = wp_insert_attachment( $attachment, $file_path, $post_id );

                        if ( ! is_wp_error( $attach_id ) ) {
                            update_post_meta( $attach_id, '_wp_attachment_image_alt', $img_alt );
                            $attach_data = wp_generate_attachment_metadata( $attach_id, $file_path );
                            wp_update_attachment_metadata( $attach_id, $attach_data );
                            set_post_thumbnail( $post_id, $attach_id );
                        }
                    }
                }
            }
        } catch ( Exception $e ) {
            // Image processing failed — log it but let the post succeed
            error_log( 'Newsroom Creator: image upload error — ' . $e->getMessage() );
        }
    }

    return new WP_REST_Response(
        array(
            'success'   => true,
            'post_id'   => $post_id,
            'edit_url'  => get_edit_post_link( $post_id, 'raw' ),
            'permalink' => get_permalink( $post_id )
        ),
        $http_status
    );
}

function newsroom_creator_get_posts( WP_REST_Request $request ) {
    $per_page = min( 100, max( 1, intval( $request->get_param('per_page') ?: 50 ) ) );
    $page     = max( 1, intval( $request->get_param('page') ?: 1 ) );

    $query = new WP_Query( array(
        'post_type'      => 'post',
        'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
        'posts_per_page' => $per_page,
        'paged'          => $page,
        'orderby'        => 'modified',
        'order'          => 'DESC',
    ) );

    $admin_url = admin_url( 'post.php' );
    $posts = array();
    foreach ( $query->posts as $post ) {
        // get_edit_post_link() returns null when called via REST (no logged-in user context).
        // Build the URL directly from admin_url so it is always correct.
        $edit_url = add_query_arg( array( 'post' => $post->ID, 'action' => 'edit' ), $admin_url );
        $posts[] = array(
            'id'        => $post->ID,
            'title'     => get_the_title( $post ),
            'status'    => $post->post_status,
            'date'      => $post->post_modified,
            'permalink' => get_permalink( $post->ID ),
            'edit_url'  => $edit_url,
        );
    }

    return new WP_REST_Response( array(
        'success'     => true,
        'posts'       => $posts,
        'total'       => (int) $query->found_posts,
        'total_pages' => (int) $query->max_num_pages,
    ), 200 );
}

function newsroom_creator_trash_post( WP_REST_Request $request ) {
    $params  = $request->get_json_params();
    $post_id = isset( $params['post_id'] ) ? intval( $params['post_id'] ) : 0;

    if ( $post_id <= 0 || ! get_post( $post_id ) ) {
        return new WP_Error( 'invalid_post', 'Post not found.', array( 'status' => 404 ) );
    }

    $result = wp_trash_post( $post_id );
    if ( ! $result ) {
        return new WP_REST_Response( array( 'success' => false, 'message' => 'Could not trash post.' ), 500 );
    }
    return new WP_REST_Response( array( 'success' => true, 'post_id' => $post_id ), 200 );
}

add_action( 'admin_menu', 'newsroom_creator_admin_menu' );

function newsroom_creator_admin_menu() {
    add_options_page('Newsroom Creator', 'Newsroom Creator', 'manage_options', 'newsroom-creator', 'newsroom_creator_settings_page');
}

function newsroom_creator_activate_key() {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    check_admin_referer( 'newsroom_creator_regen_key' );
    $key = bin2hex( random_bytes( 32 ) );
    update_option( NEWSROOM_CREATOR_OPTION_KEY, $key );
    wp_redirect( add_query_arg( array( 'page' => 'newsroom-creator', 'regen' => '1' ), admin_url( 'options-general.php' ) ) );
    exit;
}
add_action( 'admin_post_newsroom_creator_regen_key', 'newsroom_creator_activate_key' );

function newsroom_creator_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $api_key  = get_option( NEWSROOM_CREATOR_OPTION_KEY, '' );
    $site_url = home_url();
    $regen    = isset( $_GET['regen'] ) ? true : false;
    ?>
    <div class="wrap">
        <h1>Newsroom Creator — Settings</h1>
        <?php if ( $regen ) : ?>
            <div class="notice notice-success is-dismissible"><p>API key regenerated successfully.</p></div>
        <?php endif; ?>
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:24px;max-width:640px;margin-top:20px;">

            <p style="margin-bottom:6px;"><strong>WordPress Site URL</strong></p>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;">
                <input type="text" value="<?php echo esc_attr( $site_url ); ?>" readonly
                       id="nc-site-url"
                       style="flex:1;font-family:monospace;background:#f6f7f7;">
                <button type="button" class="button"
                        onclick="ncCopy('nc-site-url', this)">
                    Copy
                </button>
            </div>

            <p style="margin-bottom:6px;"><strong>API Key</strong></p>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
                <input type="text" value="<?php echo esc_attr( $api_key ); ?>" readonly
                       id="nc-api-key"
                       style="flex:1;font-family:monospace;background:#f6f7f7;">
                <button type="button" class="button"
                        onclick="ncCopy('nc-api-key', this)">
                    Copy
                </button>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                  style="margin-top:8px;"
                  onsubmit="return confirm('Regenerate the API key? The old key will stop working immediately.');">
                <?php wp_nonce_field( 'newsroom_creator_regen_key' ); ?>
                <input type="hidden" name="action" value="newsroom_creator_regen_key">
                <button type="submit" class="button button-secondary" style="color:#b32d2e;border-color:#b32d2e;">
                    &#x21BB; Regenerate API Key
                </button>
                <p class="description" style="margin-top:6px;">
                    Regenerating will invalidate the current key. You will need to update the key in the Newsroom Creator app immediately.
                </p>
            </form>

        </div>
    </div>
    <script>
    function ncCopy(inputId, btn) {
        var el = document.getElementById(inputId);
        if (!el) return;
        navigator.clipboard.writeText(el.value).then(function() {
            var orig = btn.textContent;
            btn.textContent = 'Copied!';
            btn.disabled = true;
            setTimeout(function() { btn.textContent = orig; btn.disabled = false; }, 2000);
        }).catch(function() {
            el.select();
            document.execCommand('copy');
            btn.textContent = 'Copied!';
            setTimeout(function() { btn.textContent = 'Copy'; }, 2000);
        });
    }
    </script>
    <?php
}